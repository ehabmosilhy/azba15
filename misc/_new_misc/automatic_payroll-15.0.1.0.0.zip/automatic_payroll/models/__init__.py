from . import auto_generate_payslips
from . import res_config_settings
