The development of this module has been financially supported by:

* GRAP, Groupement Régional Alimentaire de proximité (www.grap.coop)
* Vracoop (www.vracoop.fr)
