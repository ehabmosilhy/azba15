This module extends the functionnality of the Odoo Point of Sale to
allow the cashier to change the payments of a PoS order.

This feature is usefull when the user realized that he did a mistake,
just after he marked the order as paid, or during the close of the session,
Only if entries has not been generated.
