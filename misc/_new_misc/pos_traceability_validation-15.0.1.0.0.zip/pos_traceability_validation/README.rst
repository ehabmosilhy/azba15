POS Serial Number Validator v15
===============================

Validate Serial number of a product by checking availability in stock

Credits
=======
Cybrosys Techno Solutions

Author
------
* Akhilesh N S <odoo@cybrosys.com>
* V13 Sreenath
* V14 Jibin James
* V15 Mily
