Top/Least Selling Product Report v15
====================================
Top Selling and Least Selling Product Reports

Installation
============
- www.odoo.com/documentation/15.0/setup/install.html
- Install our custom addon

Configuration
=============
No additional configurations needed

Credits
=======
Developer: Ajmal JK @ cybrosys, Contact: odoo@cybrosys.com
V13 : Sreenath
V14 : Sayooj A O
V15 : Irfan @ cybrosys

