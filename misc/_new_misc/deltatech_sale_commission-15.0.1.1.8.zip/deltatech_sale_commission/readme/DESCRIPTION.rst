Features:
 - New technical access group for display margin and purchase price in customer invoice
 - Technical access group to prevent changing price in  customer invoice
 - New technical access group to allow sale price  below the purchase price
 - Warning/Error on customer invoice if sale price is below the purchase price
 - New report for analysis profitability
 - Calculation of sales commissions, on invoice salesperson or sale order salesperson (configurable)
