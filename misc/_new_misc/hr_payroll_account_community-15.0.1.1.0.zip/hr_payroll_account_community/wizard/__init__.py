#-*- coding:utf-8 -*-

from . import hr_payroll_payslips_by_employees
