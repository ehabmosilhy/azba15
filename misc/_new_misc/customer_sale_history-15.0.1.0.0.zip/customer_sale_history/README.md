Open ERP System :- Odoo 11 Version

Installation
============
Install the Application => Apps -> Customer Sale History (Technical Name: customer_sale_history)

Version
========
	Odoo 15 version

Module Configuration Guideline
==============================

	User can view the Customers Sales history on his contact form.
	From the Sales History Sales Person can learn more about your Customers and their shopping habits.
