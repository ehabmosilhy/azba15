## Module Generate Lot/Serial Number from Manufacturing order

#### 29.4.2022
#### Version 15.0.1.0.0
##### ADD
- Initial Commit for serial_no_from_mo
