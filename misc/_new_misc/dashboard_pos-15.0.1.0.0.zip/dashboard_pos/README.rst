POS Dashboard v15
=================
POS Dashboard

Installation
============
	- www.odoo.com/documentation/14.0/setup/install.html
	- Install our custom addon

Configuration
=============

    No additional configurations needed

Credits
=======
Developer: Irfan v13 @ cybrosys, Contact: odoo@cybrosys.com
           Jibin James V14 @ cybrosys, Contact: odoo@cybrosys.com
           Irfan V15 @ cybrosys, Contact: odoo@cybrosys.com

