# -*- coding: utf-8 -*-

from odoo import api, fields, models


class PosConfig(models.Model):
    _inherit = 'pos.config'

    restrict_zero_price_line = fields.Boolean(string="Restrict Zero Price Order Line")







