## Module <sales_order_double_approval>

#### 06.07.2022
#### Version 15.0.1.0.0
#### ADD
- Initial commit for Sales Order Double Approval Module
