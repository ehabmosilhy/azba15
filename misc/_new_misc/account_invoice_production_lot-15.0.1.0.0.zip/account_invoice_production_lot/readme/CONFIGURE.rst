* Go to **Inventory > Configuration > Settings > Traceability**, and activate
  option **Lots & Serial Numbers** in order to manage lots in your instance.
* Go to **Sales > Sales > Products** and select or create a storable product
  (Product Type): check that the product has **Tracking** set to **By lots**
  or to **By Unique Serial Number** (in the Inventory tab) and
  **Invoicing Policy** set to **Delivered quantities** (in the Sales tab)
