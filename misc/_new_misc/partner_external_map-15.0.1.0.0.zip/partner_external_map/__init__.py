from . import models
from .hooks import set_default_map_settings
