If you want to create additional map websites, go to the menu
*Settings > Technical > Map Websites > Map Websites*. You are
invited to send the configuration information of your additional map websites
to one of the authors of the module, so that the module can be updated with
more pre-configured map websites.
