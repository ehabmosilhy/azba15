* `Akretion <http://www.akretion.com>`__:

  * Alexis de Lattre <alexis.delattre@akretion.com>

* `Tecnativa <https://www.tecnativa.com>`__:

  * Pedro M. Baeza
  * Ernesto Tejeda
  * João Marques

* `Sygel <http://www.sygel.es>`__:

  * Manuel Regidor <manuel.regidor@sygel.es>
